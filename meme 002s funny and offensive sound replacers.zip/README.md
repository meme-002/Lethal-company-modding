
# Adds a bunch of funny ass sounds to the game including

sound replacer list:

Mine activation/explosion: Alahu akbar+music
Mine step on sound: Nut button
Mine beep: Gawr Gura A meme sound

Turret activation: Moistcritical "HE'S PULLING HIS COCK OUT!"
Turret Firing: ORDER from ULTRAKILL
Turret Berserk: Yeat Guitar Remix
Turret deactivate: you stupid N-

Death from falling: original sound+TF2 scout saying "DUMBASS!"

Lightning Strikes: original sound+tourettes guy swearing